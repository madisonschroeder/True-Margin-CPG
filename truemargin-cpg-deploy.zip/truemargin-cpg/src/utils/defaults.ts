import { CogsFreightState, ChannelInputs, SupplyChainNode, GlobalOverhead, BreakevenInputs, DebtEquityInputs } from '../types';

function makeNode(label: string): SupplyChainNode {
  return {
    label,
    rawIngredients: 0,
    primaryPackaging: 0,
    secondaryPackaging: 0,
    tollProcessing: 0,
    inboundFreight: 0,
    unitsPerCase: 0,
    casesPerPallet: 0,
    pickPackFeePerCase: 0,
    ltlFreightPerPallet: 0,
  };
}

export const defaultCogsFreight: CogsFreightState = {
  nodes: [makeNode('LTL A'), makeNode('LTL B'), makeNode('FTL')],
};

export const defaultGlobalOverhead: GlobalOverhead = {
  ceoSalary: 120000,
  fractionalServices: 100000,
  otherSGA: 50000,
  marketingPctOfNetRev: 0.10,
  annualInterestRate: 0.15,
};

function makeChannel(
  id: string,
  name: string,
  dashboardLabel: string,
  overrides: Partial<ChannelInputs> = {}
): ChannelInputs {
  return {
    id,
    name,
    dashboardLabel,
    retailerMarginPct: 0.55,
    distMarginPct: 0.12,
    productMarginPct: 0.25,
    earlyPayPct: 0.02,
    brokerCommPct: 0,
    spoilagePct: 0.01,
    tradeSpendPct: 0.15,
    slottingPerSkuPerStore: 0,
    estUnitsPerWeekPerStore: 3,
    warehousingPerPalletPerMonth: 25,
    warehousingMonthsOnHand: 1,
    warehousingUnitsPerPallet: 504,
    pctTraditionalGrocery: 1,
    pctNode1: 1,
    pctNode2: 0,
    pctNode3: 0,
    blendedInventoryDays: 90,
    arDays: 30,
    apDays: 30,
    unitsPerCase: 12,
    ...overrides,
  };
}

export const defaultChannels: Record<string, ChannelInputs> = {
  kehe: makeChannel('kehe', "NAT'L DISTRIBUTION", 'KeHE', {
    retailerMarginPct: 0.55,
    distMarginPct: 0.12,
    productMarginPct: 0.25,
    earlyPayPct: 0.02,
    brokerCommPct: 0,
    spoilagePct: 0.01,
    tradeSpendPct: 0.15,
  }),
  club: makeChannel('club', 'CLUB', 'COSTCO', {
    retailerMarginPct: 0.14,
    distMarginPct: 0,
    productMarginPct: 0.53,
    earlyPayPct: 0.01,
    brokerCommPct: 0,
    spoilagePct: 0.01,
    tradeSpendPct: 0,
    estUnitsPerWeekPerStore: 36,
    warehousingMonthsOnHand: 0.5,
  }),
  dsd: makeChannel('dsd', 'DSD', 'DSD', {
    retailerMarginPct: 0.40,
    distMarginPct: 0.25,
    productMarginPct: 0.30,
    earlyPayPct: 0.02,
    brokerCommPct: 0.05,
    spoilagePct: 0.02,
    tradeSpendPct: 0.10,
  }),
  online: makeChannel('online', 'ONLINE D2B', 'ONLINE D2B', {
    retailerMarginPct: 0.15,
    distMarginPct: 0,
    productMarginPct: 0.60,
    earlyPayPct: 0,
    brokerCommPct: 0,
    spoilagePct: 0.01,
    tradeSpendPct: 0.05,
    estUnitsPerWeekPerStore: 10,
  }),
  altfdsvc: makeChannel('altfdsvc', 'ALT FDSVC', 'ALT FDSVC', {
    retailerMarginPct: 0.30,
    distMarginPct: 0.10,
    productMarginPct: 0.35,
    earlyPayPct: 0.01,
    brokerCommPct: 0.03,
    spoilagePct: 0.01,
    tradeSpendPct: 0.05,
  }),
};

export const defaultDashboardMix: Record<string, number> = {
  kehe: 0.30,
  club: 0.20,
  dsd: 0.20,
  online: 0.10,
  altfdsvc: 0.20,
};

export const defaultBreakevenInputs: BreakevenInputs = {
  targetEbitdaDollars: 250000,
  scenarios: [
    { label: 'Survival', targetEbitda: 0 },
    { label: 'Modest Growth', targetEbitda: 100000 },
    { label: 'Aggressive', targetEbitda: 250000 },
    { label: 'Scale-Up', targetEbitda: 500000 },
  ],
};

export const defaultDebtEquityInputs: DebtEquityInputs = {
  capitalNeeded: 500000,
  debtApr: 0.15,
  debtTermYears: 3,
  equityPreMoneyVal: 3000000,
  revenueMultiple: 3,
  projectedExitYear: 5,
  projectedExitRevenue: 10000000,
};
