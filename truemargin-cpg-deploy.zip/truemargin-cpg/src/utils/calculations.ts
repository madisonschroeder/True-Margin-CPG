import {
  SupplyChainNode,
  NodeOutputs,
  ChannelInputs,
  ChannelOutputs,
  CogsFreightState,
  GlobalOverhead,
  DashboardChannel,
  BlendedFinancials,
  BreakevenInputs,
  BreakevenOutputs,
  DebtEquityInputs,
  DebtEquityOutputs,
} from '../types';

// ── SUPPLY CHAIN NODE ──
export function computeNodeOutputs(node: SupplyChainNode): NodeOutputs {
  const totalMfgCogs =
    node.rawIngredients +
    node.primaryPackaging +
    node.secondaryPackaging +
    node.tollProcessing +
    node.inboundFreight;

  const totalUnitsPerPallet = node.unitsPerCase * node.casesPerPallet;
  const threePLCostPerUnit = node.unitsPerCase > 0 ? node.pickPackFeePerCase / node.unitsPerCase : 0;
  const freightCostPerUnit = totalUnitsPerPallet > 0 ? node.ltlFreightPerPallet / totalUnitsPerPallet : 0;
  const totalOutboundPerUnit = threePLCostPerUnit + freightCostPerUnit;
  const trueLandedCogs = totalMfgCogs + totalOutboundPerUnit;

  return { totalMfgCogs, totalUnitsPerPallet, threePLCostPerUnit, freightCostPerUnit, totalOutboundPerUnit, trueLandedCogs };
}

// ── CHANNEL-LEVEL P&L (no overhead — that's global) ──
export function computeChannelOutputs(
  channel: ChannelInputs,
  cogsState: CogsFreightState
): ChannelOutputs {
  const nodeOutputs = cogsState.nodes.map(computeNodeOutputs);

  const blendedCogs =
    channel.pctNode1 * nodeOutputs[0].totalMfgCogs +
    channel.pctNode2 * nodeOutputs[1].totalMfgCogs +
    channel.pctNode3 * nodeOutputs[2].totalMfgCogs;

  const blendedFreight =
    channel.pctNode1 * nodeOutputs[0].totalOutboundPerUnit +
    channel.pctNode2 * nodeOutputs[1].totalOutboundPerUnit +
    channel.pctNode3 * nodeOutputs[2].totalOutboundPerUnit;

  const pctNonTraditional = 1 - channel.pctTraditionalGrocery;
  const blendedGtnMultiplier = channel.pctTraditionalGrocery * 1 + pctNonTraditional * 0.5;

  // Tiered Pricing
  const cogs = blendedCogs;
  const priceToDistrib = channel.productMarginPct < 1 ? cogs / (1 - channel.productMarginPct) : 0;
  const brandMarginDollar = priceToDistrib - cogs;
  const priceToRetailer = channel.distMarginPct < 1 ? priceToDistrib / (1 - channel.distMarginPct) : 0;
  const distMarginDollar = priceToRetailer - priceToDistrib;
  const msrp = channel.retailerMarginPct < 1 ? priceToRetailer / (1 - channel.retailerMarginPct) : 0;
  const retailerMarginDollar = msrp - priceToRetailer;

  // GtN Dilution
  const earlyPayDollar = priceToDistrib * channel.earlyPayPct;
  const brokerCommDollar = priceToDistrib * channel.brokerCommPct * blendedGtnMultiplier;
  const spoilageDollar = priceToDistrib * channel.spoilagePct;
  const tradeSpendDollar = priceToDistrib * channel.tradeSpendPct * blendedGtnMultiplier;
  const slottingCostPerUnit =
    channel.estUnitsPerWeekPerStore > 0
      ? (channel.slottingPerSkuPerStore / (channel.estUnitsPerWeekPerStore * 52)) * blendedGtnMultiplier
      : 0;
  const warehousingCostPerUnit =
    channel.warehousingUnitsPerPallet > 0
      ? (channel.warehousingPerPalletPerMonth * channel.warehousingMonthsOnHand) / channel.warehousingUnitsPerPallet
      : 0;
  const freightOutDollar = blendedFreight;

  const totalDeductions =
    earlyPayDollar + brokerCommDollar + spoilageDollar + tradeSpendDollar + slottingCostPerUnit + freightOutDollar;
  const netRevenue = priceToDistrib - totalDeductions;
  const contributionMarginDollar = netRevenue - cogs;
  const contributionMarginPct = netRevenue !== 0 ? contributionMarginDollar / netRevenue : 0;

  // Working Capital (channel-level)
  const cashConversionCycle = channel.blendedInventoryDays + channel.arDays - channel.apDays;

  return {
    blendedCogs, blendedFreight, blendedGtnMultiplier,
    msrp, retailerMarginDollar, priceToRetailer, distMarginDollar, priceToDistrib, brandMarginDollar,
    earlyPayDollar, brokerCommDollar, spoilageDollar, tradeSpendDollar, slottingCostPerUnit,
    warehousingCostPerUnit, freightOutDollar,
    totalDeductions, netRevenue, contributionMarginDollar, contributionMarginPct,
    cashConversionCycle,
  };
}

// ── BLENDED COMPANY-LEVEL FINANCIALS (Executive Dashboard) ──
export function computeBlendedFinancials(
  channelInputs: Record<string, ChannelInputs>,
  cogsState: CogsFreightState,
  globalOverhead: GlobalOverhead,
  dashboardMix: Record<string, number>,
  targetAnnualNetRev: number
): BlendedFinancials {
  const channelIds = ['kehe', 'club', 'dsd', 'online', 'altfdsvc'];

  // Compute each channel
  const channelResults = channelIds.map((id) => ({
    id,
    inputs: channelInputs[id],
    outputs: computeChannelOutputs(channelInputs[id], cogsState),
    mix: dashboardMix[id] || 0,
  }));

  const channels: DashboardChannel[] = channelResults.map((cr) => ({
    id: cr.id,
    name: cr.inputs.dashboardLabel,
    mixPct: cr.mix,
    netRevPerUnit: cr.outputs.netRevenue,
    contributionMarginPerUnit: cr.outputs.contributionMarginDollar,
    contributionMarginPct: cr.outputs.contributionMarginPct,
    cogsPerUnit: cr.outputs.blendedCogs,
    cccDays: cr.outputs.cashConversionCycle,
  }));

  // Blended per-unit metrics
  const blendedNetRev = channels.reduce((s, c) => s + c.mixPct * c.netRevPerUnit, 0);
  const blendedContribMargin = channels.reduce((s, c) => s + c.mixPct * c.contributionMarginPerUnit, 0);
  const blendedContribMarginPct = blendedNetRev !== 0 ? blendedContribMargin / blendedNetRev : 0;
  const blendedCogs = channels.reduce((s, c) => s + c.mixPct * c.cogsPerUnit, 0);
  const blendedCCC = channels.reduce((s, c) => s + c.mixPct * c.cccDays, 0);

  // Blended AR/AP (weighted by mix)
  const blendedAR = channelResults.reduce((s, cr) => s + cr.mix * cr.inputs.arDays, 0);
  const blendedAP = channelResults.reduce((s, cr) => s + cr.mix * cr.inputs.apDays, 0);
  const blendedInventoryDays = channelResults.reduce((s, cr) => s + cr.mix * cr.inputs.blendedInventoryDays, 0);

  // Global overhead
  const totalFixedCosts = globalOverhead.ceoSalary + globalOverhead.fractionalServices + globalOverhead.otherSGA;
  const marketingPerUnit = blendedNetRev * globalOverhead.marketingPctOfNetRev;
  const adjustedContribMargin = blendedContribMargin - marketingPerUnit;

  // Run-Rate
  const impliedUnits = blendedNetRev !== 0 ? targetAnnualNetRev / blendedNetRev : 0;
  const blendedCashGenerated = impliedUnits * adjustedContribMargin;
  const annualOverhead = totalFixedCosts;
  const annualMarketing = impliedUnits * marketingPerUnit;
  const operatingCashFlow = blendedCashGenerated - annualOverhead;

  // Working Capital (company-level, blended)
  const peakInventoryCash = (impliedUnits * blendedCogs * blendedInventoryDays) / 365;
  const accountsReceivable = (targetAnnualNetRev * blendedAR) / 365;
  const accountsPayable = (impliedUnits * blendedCogs * blendedAP) / 365;
  const netWorkingCapital = peakInventoryCash + accountsReceivable - accountsPayable;
  const overheadBurnDuringCycle = (totalFixedCosts / 365) * blendedCCC;
  const totalCashFloat = netWorkingCapital + overheadBurnDuringCycle;

  // Cost of Capital (company-level)
  const annualInterestCost = totalCashFloat * globalOverhead.annualInterestRate;
  const debtBurdenPerUnit = impliedUnits > 0 ? annualInterestCost / impliedUnits : 0;
  const finalCashMarginPerUnit = adjustedContribMargin - debtBurdenPerUnit;
  const maxAllowableApr =
    totalCashFloat > 0 && impliedUnits > 0
      ? (adjustedContribMargin * impliedUnits - annualOverhead) / totalCashFloat
      : 0;
  const debtViability = finalCashMarginPerUnit <= 0 ? 'ABORT: DEBT IS TOO EXPENSIVE' : operatingCashFlow <= 0 ? 'WARNING: NEGATIVE OPERATING CASH FLOW' : 'VIABLE FINANCING';

  // Self-Funded Growth
  const newUnitsPerSold = blendedCogs !== 0 ? adjustedContribMargin / blendedCogs : 0;
  const annualCapitalTurns = blendedCCC !== 0 ? 365 / blendedCCC : 0;
  const maxSelfFundedGrowth = newUnitsPerSold * annualCapitalTurns;

  // Valuation Estimator
  const impliedRevenueMultiple = operatingCashFlow > 0 ? totalCashFloat / operatingCashFlow : 0;

  return {
    channels,
    blendedNetRev, blendedContribMargin, blendedContribMarginPct, blendedCogs, blendedCCC,
    totalFixedCosts, marketingPerUnit, adjustedContribMargin,
    targetAnnualNetRev, impliedUnits, blendedCashGenerated, annualOverhead, annualMarketing, operatingCashFlow,
    peakInventoryCash, accountsReceivable, accountsPayable, netWorkingCapital, overheadBurnDuringCycle, totalCashFloat,
    annualInterestCost, debtBurdenPerUnit, finalCashMarginPerUnit, maxAllowableApr, debtViability,
    newUnitsPerSold, annualCapitalTurns, maxSelfFundedGrowth,
    impliedRevenueMultiple,
  };
}

// ── BREAKEVEN & TARGET EBITDA ──
export function computeBreakeven(
  blended: BlendedFinancials,
  inputs: BreakevenInputs
): BreakevenOutputs {
  const fixedCosts = blended.totalFixedCosts;
  const contribPerUnit = blended.adjustedContribMargin;
  const netRevPerUnit = blended.blendedNetRev;

  const calcUnits = (targetEbitda: number): number | string => {
    if (contribPerUnit <= 0) return 'NEGATIVE MARGIN - DO NOT SELL';
    return (fixedCosts + targetEbitda) / contribPerUnit;
  };

  const calcRev = (units: number | string): number | string => {
    if (typeof units === 'string') return 'N/A';
    return units * netRevPerUnit;
  };

  const calcPallets = (units: number | string): number | string => {
    if (typeof units === 'string') return 'N/A';
    return units / 504;
  };

  // Breakeven (EBITDA = 0)
  const breakevenUnits = calcUnits(0);
  const breakevenRevenue = calcRev(breakevenUnits);
  const breakevenPallets = calcPallets(breakevenUnits);
  const breakevenContainers = typeof breakevenPallets === 'number' ? breakevenPallets / 20 : 'N/A';

  // Target
  const targetUnits = calcUnits(inputs.targetEbitdaDollars);
  const targetRevenue = calcRev(targetUnits);
  const targetPallets = calcPallets(targetUnits);
  const targetContainers = typeof targetPallets === 'number' ? targetPallets / 20 : 'N/A';

  // Scenarios
  const scenarios = inputs.scenarios.map((s) => {
    const u = calcUnits(s.targetEbitda);
    return {
      label: s.label,
      targetEbitda: s.targetEbitda,
      requiredUnits: u,
      requiredRevenue: calcRev(u),
      requiredPallets: calcPallets(u),
    };
  });

  return {
    breakevenUnits, breakevenRevenue, breakevenPallets, breakevenContainers,
    targetUnits, targetRevenue, targetPallets, targetContainers,
    adjustedContribPerUnit: contribPerUnit,
    totalFixedCosts: fixedCosts,
    scenarios,
  };
}

// ── DEBT VS EQUITY DECISION TOOL ──
export function computeDebtVsEquity(
  blended: BlendedFinancials,
  inputs: DebtEquityInputs
): DebtEquityOutputs {
  const { capitalNeeded, debtApr, debtTermYears, equityPreMoneyVal, projectedExitYear, projectedExitRevenue, revenueMultiple } = inputs;

  // Debt Path
  // Monthly payment for amortizing loan
  const monthlyRate = debtApr / 12;
  const numPayments = debtTermYears * 12;
  const monthlyPayment = monthlyRate > 0
    ? (capitalNeeded * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1)
    : capitalNeeded / numPayments;
  const annualDebtService = monthlyPayment * 12;
  const totalDebtCost = (monthlyPayment * numPayments) - capitalNeeded;
  const debtServiceCoverage = annualDebtService > 0 ? blended.operatingCashFlow / annualDebtService : 0;
  const debtFeasible = debtServiceCoverage >= 1.25;

  // Equity Path
  const postMoneyVal = equityPreMoneyVal + capitalNeeded;
  const equityDilution = capitalNeeded / postMoneyVal;
  const impliedOwnershipRetained = 1 - equityDilution;
  const projectedExitVal = projectedExitRevenue * revenueMultiple;
  const investorReturnAtExit = projectedExitVal * equityDilution;
  const founderValueAtExit = projectedExitVal * impliedOwnershipRetained;
  const costOfEquity = investorReturnAtExit - capitalNeeded;

  // Comparison
  const debtCostAsMultiple = capitalNeeded > 0 ? totalDebtCost / capitalNeeded : 0;
  const equityCostAsMultiple = capitalNeeded > 0 ? costOfEquity / capitalNeeded : 0;
  let recommendation: string;
  if (!debtFeasible && costOfEquity <= 0) {
    recommendation = 'NEITHER: Operating cash flow insufficient for debt; equity terms undervalue the business.';
  } else if (!debtFeasible) {
    recommendation = 'EQUITY: Operating cash flow insufficient to service debt at this term.';
  } else if (totalDebtCost < costOfEquity) {
    recommendation = 'DEBT: Lower total cost of capital; retain full ownership.';
  } else if (costOfEquity < totalDebtCost) {
    recommendation = 'EQUITY: Lower implied cost; debt service too burdensome.';
  } else {
    recommendation = 'BLENDED: Consider a mix of debt + equity to optimize cost and dilution.';
  }

  return {
    annualDebtService, totalDebtCost: totalDebtCost, monthlyPayment, debtServiceCoverage, debtFeasible,
    equityDilution, postMoneyVal, impliedOwnershipRetained, investorReturnAtExit, founderValueAtExit, costOfEquity,
    debtTotalCost: totalDebtCost, equityTotalCost: costOfEquity,
    recommendation, debtCostAsMultiple, equityCostAsMultiple,
  };
}
