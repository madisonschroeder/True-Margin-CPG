// Supply Chain Node (LTL A, LTL B, FTL)
export interface SupplyChainNode {
  label: string;
  rawIngredients: number;
  primaryPackaging: number;
  secondaryPackaging: number;
  tollProcessing: number;
  inboundFreight: number;
  unitsPerCase: number;
  casesPerPallet: number;
  pickPackFeePerCase: number;
  ltlFreightPerPallet: number;
}

export interface CogsFreightState {
  nodes: [SupplyChainNode, SupplyChainNode, SupplyChainNode];
}

// Computed outputs from a supply chain node
export interface NodeOutputs {
  totalMfgCogs: number;
  totalUnitsPerPallet: number;
  threePLCostPerUnit: number;
  freightCostPerUnit: number;
  totalOutboundPerUnit: number;
  trueLandedCogs: number;
}

// ── GLOBAL COMPANY-LEVEL INPUTS (entered once, allocated proportionally) ──
export interface GlobalOverhead {
  ceoSalary: number;
  fractionalServices: number;
  otherSGA: number;
  marketingPctOfNetRev: number;
  annualInterestRate: number;
}

// Channel-specific inputs (no overhead — that's global now)
export interface ChannelInputs {
  id: string;
  name: string;
  dashboardLabel: string;
  // Tiered Pricing
  retailerMarginPct: number;
  distMarginPct: number;
  productMarginPct: number;
  // GtN Dilution
  earlyPayPct: number;
  brokerCommPct: number;
  spoilagePct: number;
  tradeSpendPct: number;
  slottingPerSkuPerStore: number;
  estUnitsPerWeekPerStore: number;
  warehousingPerPalletPerMonth: number;
  warehousingMonthsOnHand: number;
  warehousingUnitsPerPallet: number;
  // Channel Mixer
  pctTraditionalGrocery: number;
  // Supply Chain Mixer
  pctNode1: number;
  pctNode2: number;
  pctNode3: number;
  blendedInventoryDays: number;
  // Working Capital
  arDays: number;
  apDays: number;
  // Unit conversion
  unitsPerCase: number;
}

// Computed channel outputs
export interface ChannelOutputs {
  blendedCogs: number;
  blendedFreight: number;
  blendedGtnMultiplier: number;
  msrp: number;
  retailerMarginDollar: number;
  priceToRetailer: number;
  distMarginDollar: number;
  priceToDistrib: number;
  brandMarginDollar: number;
  earlyPayDollar: number;
  brokerCommDollar: number;
  spoilageDollar: number;
  tradeSpendDollar: number;
  slottingCostPerUnit: number;
  warehousingCostPerUnit: number;
  freightOutDollar: number;
  totalDeductions: number;
  netRevenue: number;
  contributionMarginDollar: number;
  contributionMarginPct: number;
  // Working Capital (channel-level)
  cashConversionCycle: number;
}

// ── EXECUTIVE DASHBOARD ──
export interface DashboardChannel {
  id: string;
  name: string;
  mixPct: number;
  netRevPerUnit: number;
  contributionMarginPerUnit: number;
  contributionMarginPct: number;
  cogsPerUnit: number;
  cccDays: number;
}

export interface BlendedFinancials {
  // Channel summary
  channels: DashboardChannel[];
  blendedNetRev: number;
  blendedContribMargin: number;
  blendedContribMarginPct: number;
  blendedCogs: number;
  blendedCCC: number;

  // Global Overhead applied
  totalFixedCosts: number;
  marketingPerUnit: number;
  adjustedContribMargin: number;

  // Run-Rate Cash Generator
  targetAnnualNetRev: number;
  impliedUnits: number;
  blendedCashGenerated: number;
  annualOverhead: number;
  annualMarketing: number;
  operatingCashFlow: number; // EBITDA proxy

  // Working Capital & Cash Needs (blended)
  peakInventoryCash: number;
  accountsReceivable: number;
  accountsPayable: number;
  netWorkingCapital: number;
  overheadBurnDuringCycle: number;
  totalCashFloat: number;

  // Cost of Capital (blended)
  annualInterestCost: number;
  debtBurdenPerUnit: number;
  finalCashMarginPerUnit: number;
  maxAllowableApr: number;
  debtViability: string;

  // Self-Funded Growth
  newUnitsPerSold: number;
  annualCapitalTurns: number;
  maxSelfFundedGrowth: number;

  // Valuation Estimator
  impliedRevenueMultiple: number;
}

// ── BREAKEVEN & TARGET EBITDA ──
export interface BreakevenInputs {
  targetEbitdaDollars: number;
  scenarios: { label: string; targetEbitda: number }[];
}

export interface BreakevenOutputs {
  breakevenUnits: number | string;
  breakevenRevenue: number | string;
  breakevenPallets: number | string;
  breakevenContainers: number | string;
  targetUnits: number | string;
  targetRevenue: number | string;
  targetPallets: number | string;
  targetContainers: number | string;
  adjustedContribPerUnit: number;
  totalFixedCosts: number;
  scenarios: {
    label: string;
    targetEbitda: number;
    requiredUnits: number | string;
    requiredRevenue: number | string;
    requiredPallets: number | string;
  }[];
}

// ── DEBT VS EQUITY DECISION TOOL ──
export interface DebtEquityInputs {
  capitalNeeded: number;
  debtApr: number;
  debtTermYears: number;
  equityPreMoneyVal: number;
  revenueMultiple: number;
  projectedExitYear: number;
  projectedExitRevenue: number;
}

export interface DebtEquityOutputs {
  // Debt Path
  annualDebtService: number;
  totalDebtCost: number;
  monthlyPayment: number;
  debtServiceCoverage: number;
  debtFeasible: boolean;

  // Equity Path
  equityDilution: number;
  postMoneyVal: number;
  impliedOwnershipRetained: number;
  investorReturnAtExit: number;
  founderValueAtExit: number;
  costOfEquity: number;

  // Comparison
  debtTotalCost: number;
  equityTotalCost: number;
  recommendation: string;
  debtCostAsMultiple: number;
  equityCostAsMultiple: number;
}

export type TabId = 'cogs' | 'kehe' | 'club' | 'dsd' | 'online' | 'altfdsvc' | 'overhead' | 'breakeven' | 'debtequity' | 'dashboard';

export interface AppState {
  activeTab: TabId;
  cogsFreight: CogsFreightState;
  channels: Record<string, ChannelInputs>;
  globalOverhead: GlobalOverhead;
  dashboardMix: Record<string, number>;
  dashboardTargetRev: number;
  breakevenInputs: BreakevenInputs;
  debtEquityInputs: DebtEquityInputs;
}
