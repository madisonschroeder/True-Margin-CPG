import React from 'react'
import { useNavigate } from 'react-router-dom'

const Landing: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white">
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Logo" className="h-10 w-auto" />
          <span className="text-xl font-bold tracking-tight">MIREPOIX PARTNERS</span>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/app')}
            className="px-4 py-2 text-sm text-gray-300 hover:text-white transition-colors"
          >
            Login
          </button>
          <a
            href="https://buy.stripe.com/test_3cI9AT9sG5Dd3oX0yv3cc00"
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm font-semibold transition-colors"
          >
            Subscribe
          </a>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-5xl mx-auto px-6 pt-20 pb-16 text-center">
        <div className="inline-block px-4 py-1.5 bg-blue-600/20 border border-blue-500/30 rounded-full text-blue-400 text-sm font-medium mb-6">
          🚀 Now in Beta — Founding Member Pricing
        </div>
        <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-6 leading-tight">
          TRUE MARGIN
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">CPG</span>
        </h1>
        <p className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto mb-10 leading-relaxed">
          The only gross-to-net margin calculator built for CPG founders who need to know their 
          <strong className="text-white"> real numbers</strong> — across every channel, every scenario, every decision.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="https://buy.stripe.com/test_3cI9AT9sG5Dd3oX0yv3cc00"
            className="px-8 py-4 bg-blue-600 hover:bg-blue-700 rounded-xl text-lg font-bold transition-all hover:scale-105 shadow-lg shadow-blue-600/25"
          >
            Start Now — $299/mo
          </a>
          <button
            onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 border border-gray-600 hover:border-gray-500 rounded-xl text-lg font-medium transition-colors"
          >
            See What's Inside ↓
          </button>
        </div>
      </section>

      {/* Social proof */}
      <section className="max-w-4xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-6">
            <div className="text-3xl font-bold text-blue-400 mb-2">5</div>
            <div className="text-gray-400">Sales Channels Modeled</div>
          </div>
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-6">
            <div className="text-3xl font-bold text-blue-400 mb-2">∞</div>
            <div className="text-gray-400">What-If Scenarios</div>
          </div>
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-6">
            <div className="text-3xl font-bold text-blue-400 mb-2">1</div>
            <div className="text-gray-400">Blended Truth</div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="max-w-6xl mx-auto px-6 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Everything You Need to Model Your CPG Business</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            {
              title: 'Gross-to-Net by Channel',
              desc: 'Model 5 distinct channels — National Distribution, Club, DSD, Online D2B, and Alt Foodservice — each with their own trade spend, slotting fees, and margin structure.',
              icon: '📊'
            },
            {
              title: 'COGS & Freight Builder',
              desc: 'Build your landed cost from ingredients, packaging, labor, and freight across 3 supply chain nodes with automatic blending.',
              icon: '🚛'
            },
            {
              title: 'Blended Executive Dashboard',
              desc: 'See the company-wide truth — weighted by your actual channel mix. Working capital, cost of capital, cash needs, and growth runway all in one view.',
              icon: '🎛️'
            },
            {
              title: 'Breakeven & EBITDA Targeting',
              desc: 'Model breakeven scenarios and set target EBITDA levels. Run unlimited what-if analyses with our built-in scenario modeler.',
              icon: '🎯'
            },
            {
              title: 'Debt vs. Equity Decision Tool',
              desc: 'Compare loan amortization, DSCR, and interest costs against equity dilution, valuations, and investor returns — with an algorithmic recommendation.',
              icon: '⚖️'
            },
            {
              title: 'Corporate Overhead Allocation',
              desc: 'Input overhead once. It flows proportionally across all channels, giving you the true fully-loaded margin picture.',
              icon: '🏢'
            },
          ].map((f, i) => (
            <div key={i} className="bg-gray-800/40 border border-gray-700/40 rounded-xl p-6 hover:border-blue-500/30 transition-colors">
              <div className="text-3xl mb-3">{f.icon}</div>
              <h3 className="text-xl font-bold mb-2">{f.title}</h3>
              <p className="text-gray-400 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="max-w-3xl mx-auto px-6 py-16">
        <div className="bg-gradient-to-br from-gray-800 to-gray-800/50 border border-blue-500/30 rounded-2xl p-10 text-center">
          <div className="text-sm text-blue-400 font-medium mb-2">FOUNDING MEMBER PRICING</div>
          <div className="text-5xl font-black mb-2">$299<span className="text-xl font-normal text-gray-400">/mo</span></div>
          <p className="text-gray-400 mb-8 max-w-md mx-auto">
            Full access to True Margin CPG. Model every channel, scenario, and capital decision your CPG brand faces.
          </p>
          <a
            href="https://buy.stripe.com/test_3cI9AT9sG5Dd3oX0yv3cc00"
            className="inline-block px-10 py-4 bg-blue-600 hover:bg-blue-700 rounded-xl text-lg font-bold transition-all hover:scale-105 shadow-lg shadow-blue-600/25"
          >
            Subscribe & Get Access
          </a>
          <p className="text-gray-500 text-sm mt-4">Cancel anytime. Access code delivered after payment.</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-8 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between gap-4 text-gray-500 text-sm">
        <div className="flex items-center gap-2">
          <img src="/logo.png" alt="Logo" className="h-6 w-auto opacity-50" />
          <span>© {new Date().getFullYear()} Mirepoix Partners. All rights reserved.</span>
        </div>
        <div className="flex gap-6">
          <a href="https://www.mirepoixpartners.com" className="hover:text-gray-300 transition-colors">Main Site</a>
        </div>
      </footer>
    </div>
  )
}

export default Landing
