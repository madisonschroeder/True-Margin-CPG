import React from 'react';
import { ChannelInputs, CogsFreightState } from '../types';
import { computeChannelOutputs } from '../utils/calculations';
import { fmtCurrency, fmtPct } from '../utils/formatters';
import { InputRow, OutputRow, SectionHeader } from './InputRow';

interface ChannelTabProps {
  channel: ChannelInputs;
  cogsState: CogsFreightState;
  onChange: (channel: ChannelInputs) => void;
}

export const ChannelTab: React.FC<ChannelTabProps> = ({ channel, cogsState, onChange }) => {
  const out = computeChannelOutputs(channel, cogsState);

  const update = (field: keyof ChannelInputs, value: number) => {
    onChange({ ...channel, [field]: value });
  };

  return (
    <div className="space-y-1">
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Left Column — Pricing & GtN */}
        <div className="space-y-1">
          <SectionHeader title="TIERED PRICING ARCHITECTURE" />
          <OutputRow label="MSRP" value={fmtCurrency(out.msrp)} />
          <InputRow label="Retailer Margin %" value={channel.retailerMarginPct} onChange={(v) => update('retailerMarginPct', v)} type="percent" highlight />
          <OutputRow label="Retailer Margin $" value={fmtCurrency(out.retailerMarginDollar)} />
          <OutputRow label="Price to Retailer" value={fmtCurrency(out.priceToRetailer)} accent />
          <InputRow label="Dist Margin %" value={channel.distMarginPct} onChange={(v) => update('distMarginPct', v)} type="percent" highlight />
          <OutputRow label="Dist Margin $" value={fmtCurrency(out.distMarginDollar)} />
          <OutputRow label="Price to Distrib." value={fmtCurrency(out.priceToDistrib)} accent />
          <OutputRow label="COGS" value={fmtCurrency(out.blendedCogs)} />
          <OutputRow label="Brand Margin $" value={fmtCurrency(out.brandMarginDollar)} />
          <InputRow label="Product Margin %" value={channel.productMarginPct} onChange={(v) => update('productMarginPct', v)} type="percent" highlight />

          <SectionHeader title="GROSS TO NET DILUTION" />
          <InputRow label="Early Pay %" value={channel.earlyPayPct} onChange={(v) => update('earlyPayPct', v)} type="percent" highlight />
          <OutputRow label="Early Pay $" value={fmtCurrency(out.earlyPayDollar)} />
          <InputRow label="Broker Comm %" value={channel.brokerCommPct} onChange={(v) => update('brokerCommPct', v)} type="percent" highlight />
          <OutputRow label="Broker Comm $" value={fmtCurrency(out.brokerCommDollar)} />
          <InputRow label="Spoilage %" value={channel.spoilagePct} onChange={(v) => update('spoilagePct', v)} type="percent" highlight />
          <OutputRow label="Spoilage $" value={fmtCurrency(out.spoilageDollar)} />
          <InputRow label="Trade Spend %" value={channel.tradeSpendPct} onChange={(v) => update('tradeSpendPct', v)} type="percent" highlight />
          <OutputRow label="Trade Spend $" value={fmtCurrency(out.tradeSpendDollar)} />
          <InputRow label="Slotting: $/SKU/Store" value={channel.slottingPerSkuPerStore} onChange={(v) => update('slottingPerSkuPerStore', v)} type="currency" highlight />
          <InputRow label="Est. Units/Wk/Store (UPSW)" value={channel.estUnitsPerWeekPerStore} onChange={(v) => update('estUnitsPerWeekPerStore', v)} highlight />
          <OutputRow label="Slotting: Cost / Unit" value={fmtCurrency(out.slottingCostPerUnit)} />
          <InputRow label="Warehousing: $/Pallet/Month" value={channel.warehousingPerPalletPerMonth} onChange={(v) => update('warehousingPerPalletPerMonth', v)} type="currency" highlight />
          <InputRow label="Warehousing: Months on Hand" value={channel.warehousingMonthsOnHand} onChange={(v) => update('warehousingMonthsOnHand', v)} highlight />
          <InputRow label="Warehousing: Units/Pallet" value={channel.warehousingUnitsPerPallet} onChange={(v) => update('warehousingUnitsPerPallet', v)} highlight />
          <OutputRow label="Warehousing: Cost / Unit" value={fmtCurrency(out.warehousingCostPerUnit)} />
          <OutputRow label="Freight Out $" value={fmtCurrency(out.freightOutDollar)} />
          <div className="divider my-1"></div>
          <OutputRow label="TOTAL DEDUCTIONS" value={fmtCurrency(out.totalDeductions)} bold />
          <OutputRow label="NET REVENUE" value={fmtCurrency(out.netRevenue)} accent bold />
          <OutputRow label="CONTRIBUTION MARGIN $" value={fmtCurrency(out.contributionMarginDollar)} accent bold />
          <OutputRow label="CONTRIBUTION MARGIN %" value={fmtPct(out.contributionMarginPct)} accent />
        </div>

        {/* Right Column — Mixers & Working Capital */}
        <div className="space-y-1">
          <SectionHeader title="CHANNEL MIXER" subtitle="INPUTS" />
          <InputRow label="% Traditional Grocery Vol" value={channel.pctTraditionalGrocery} onChange={(v) => update('pctTraditionalGrocery', v)} type="percent" highlight />
          <OutputRow label="% Non-Traditional Vol" value={fmtPct(1 - channel.pctTraditionalGrocery)} />
          <OutputRow label="Blended GTN Multiplier" value={out.blendedGtnMultiplier.toFixed(2)} />

          <SectionHeader title="SUPPLY CHAIN MIXER" subtitle="INPUTS" />
          <InputRow label="% Vol from LTL A" value={channel.pctNode1} onChange={(v) => update('pctNode1', v)} type="percent" highlight />
          <InputRow label="% Vol from LTL B" value={channel.pctNode2} onChange={(v) => update('pctNode2', v)} type="percent" highlight />
          <InputRow label="% Vol from FTL" value={channel.pctNode3} onChange={(v) => update('pctNode3', v)} type="percent" highlight />
          <OutputRow label="Blended COGS $" value={fmtCurrency(out.blendedCogs)} accent />
          <OutputRow label="Blended Freight $" value={fmtCurrency(out.blendedFreight)} />
          <InputRow label="Blended Inventory Days" value={channel.blendedInventoryDays} onChange={(v) => update('blendedInventoryDays', v)} highlight />

          <SectionHeader title="WORKING CAPITAL TERMS" subtitle="INPUTS" />
          <OutputRow label="Days in Inventory" value={channel.blendedInventoryDays.toString()} />
          <InputRow label="AR Terms: Days to Get Paid" value={channel.arDays} onChange={(v) => update('arDays', v)} highlight />
          <InputRow label="AP Terms: Days to Pay Supplier" value={channel.apDays} onChange={(v) => update('apDays', v)} highlight />
          <OutputRow label="Cash Conversion Cycle (Days)" value={out.cashConversionCycle.toString()} accent />

          <div className="alert alert-info mt-4 text-sm">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="stroke-current shrink-0 w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Corporate overhead, SG&A, targets & cost of capital are managed globally on the <strong>Company Overhead</strong> tab and flow through the <strong>Executive Dashboard</strong> blended view.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
