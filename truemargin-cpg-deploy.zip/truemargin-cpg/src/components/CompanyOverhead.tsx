import React from 'react';
import { GlobalOverhead } from '../types';
import { fmtCurrency, fmtPct } from '../utils/formatters';
import { InputRow, OutputRow, SectionHeader } from './InputRow';

interface Props {
  overhead: GlobalOverhead;
  onChange: (o: GlobalOverhead) => void;
}

export const CompanyOverhead: React.FC<Props> = ({ overhead, onChange }) => {
  const update = (field: keyof GlobalOverhead, value: number) => {
    onChange({ ...overhead, [field]: value });
  };

  const totalFixed = overhead.ceoSalary + overhead.fractionalServices + overhead.otherSGA;
  const monthlyBurn = totalFixed / 12;

  return (
    <div className="max-w-2xl mx-auto space-y-1">
      <div className="alert alert-info mb-4 text-sm">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="stroke-current shrink-0 w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <span>These inputs apply <strong>company-wide</strong> across all channels. They flow into the Executive Dashboard, Breakeven Analysis, and Debt vs. Equity tools as a blended reality.</span>
      </div>

      <SectionHeader title="FIXED CORPORATE OVERHEAD" subtitle="ANNUAL" />
      <InputRow label="CEO / Founder Salary" value={overhead.ceoSalary} onChange={(v) => update('ceoSalary', v)} type="currency" highlight />
      <InputRow label="Fractional Services (CFO, CMO, etc.)" value={overhead.fractionalServices} onChange={(v) => update('fractionalServices', v)} type="currency" highlight />
      <InputRow label="Other SG&A (Rent, Insurance, Legal, etc.)" value={overhead.otherSGA} onChange={(v) => update('otherSGA', v)} type="currency" highlight />
      <div className="divider my-1"></div>
      <OutputRow label="Total Fixed Overhead (Annual)" value={fmtCurrency(totalFixed)} accent bold />
      <OutputRow label="Monthly Burn Rate" value={fmtCurrency(monthlyBurn)} />
      <OutputRow label="Daily Burn Rate" value={fmtCurrency(totalFixed / 365)} />

      <SectionHeader title="VARIABLE SG&A" subtitle="AS % OF NET REVENUE" />
      <InputRow label="Marketing & Other % of Net Rev" value={overhead.marketingPctOfNetRev} onChange={(v) => update('marketingPctOfNetRev', v)} type="percent" highlight />
      <OutputRow label="Effective Rate" value={fmtPct(overhead.marketingPctOfNetRev)} />

      <SectionHeader title="COST OF CAPITAL" subtitle="COMPANY-WIDE" />
      <InputRow label="Annual Interest Rate (APR %)" value={overhead.annualInterestRate} onChange={(v) => update('annualInterestRate', v)} type="percent" highlight />

      <div className="mt-6 p-4 bg-base-200 rounded-lg">
        <h3 className="font-bold text-sm mb-2 text-base-content/80">💡 HOW THIS WORKS</h3>
        <ul className="text-xs text-base-content/70 space-y-1 list-disc ml-4">
          <li>Fixed overhead is allocated proportionally across channels based on the <strong>channel mix %</strong> set on the Executive Dashboard.</li>
          <li>Variable SG&A (marketing) is applied as a % of blended net revenue per unit.</li>
          <li>The interest rate flows into the cost of capital calculations for the full blended company view.</li>
          <li>All downstream tabs (Breakeven, Dashboard, Debt vs. Equity) use these global values automatically.</li>
        </ul>
      </div>
    </div>
  );
};
