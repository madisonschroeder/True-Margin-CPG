import React from 'react';
import { BlendedFinancials, DebtEquityInputs } from '../types';
import { computeDebtVsEquity } from '../utils/calculations';
import { fmtCurrency, fmtPct, fmtNumber } from '../utils/formatters';
import { InputRow, OutputRow, SectionHeader } from './InputRow';

interface Props {
  blended: BlendedFinancials;
  inputs: DebtEquityInputs;
  onChange: (inputs: DebtEquityInputs) => void;
}

export const DebtEquityTab: React.FC<Props> = ({ blended, inputs, onChange }) => {
  const out = computeDebtVsEquity(blended, inputs);

  const update = (field: keyof DebtEquityInputs, value: number) => {
    onChange({ ...inputs, [field]: value });
  };

  const isDebtRecommended = out.recommendation.startsWith('DEBT');
  const isEquityRecommended = out.recommendation.startsWith('EQUITY');

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="alert alert-info text-sm">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="stroke-current shrink-0 w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <span>This tool uses your <strong>blended channel reality</strong> from the Executive Dashboard to evaluate financing options. Operating Cash Flow: <strong>{fmtCurrency(blended.operatingCashFlow)}</strong></span>
      </div>

      {/* Capital Needed */}
      <div className="max-w-lg mx-auto">
        <SectionHeader title="CAPITAL REQUIREMENT" />
        <InputRow label="Total Capital Needed" value={inputs.capitalNeeded} onChange={(v) => update('capitalNeeded', v)} type="currency" highlight />
        <OutputRow label="Working Capital Gap (from Dashboard)" value={fmtCurrency(Math.max(blended.totalCashFloat - blended.operatingCashFlow, 0))} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* DEBT PATH */}
        <div className={`card ${isDebtRecommended ? 'ring-2 ring-success' : ''} bg-base-200`}>
          <div className="card-body p-4 space-y-1">
            <div className="flex items-center justify-between">
              <h2 className="card-title text-sm">🏦 DEBT PATH</h2>
              {isDebtRecommended && <span className="badge badge-success badge-sm">RECOMMENDED</span>}
            </div>

            <SectionHeader title="LOAN TERMS" subtitle="INPUTS" />
            <InputRow label="Annual Interest Rate (APR)" value={inputs.debtApr} onChange={(v) => update('debtApr', v)} type="percent" highlight />
            <InputRow label="Loan Term (Years)" value={inputs.debtTermYears} onChange={(v) => update('debtTermYears', v)} highlight />

            <SectionHeader title="DEBT SERVICE ANALYSIS" subtitle="OUTPUTS" />
            <OutputRow label="Monthly Payment" value={fmtCurrency(out.monthlyPayment)} />
            <OutputRow label="Annual Debt Service" value={fmtCurrency(out.annualDebtService)} bold />
            <OutputRow label="Total Interest Paid" value={fmtCurrency(out.totalDebtCost)} accent />
            <OutputRow label="Cost as Multiple of Principal" value={fmtNumber(out.debtCostAsMultiple, 2) + 'x'} />
            <OutputRow
              label="Debt Service Coverage Ratio"
              value={fmtNumber(out.debtServiceCoverage, 2) + 'x'}
              accent={out.debtFeasible}
              danger={!out.debtFeasible}
            />
            <OutputRow
              label="FEASIBILITY"
              value={out.debtFeasible ? '✅ SERVICEABLE (DSCR ≥ 1.25x)' : '🛑 INSUFFICIENT CASH FLOW (DSCR < 1.25x)'}
              accent={out.debtFeasible}
              danger={!out.debtFeasible}
              bold
            />
          </div>
        </div>

        {/* EQUITY PATH */}
        <div className={`card ${isEquityRecommended ? 'ring-2 ring-success' : ''} bg-base-200`}>
          <div className="card-body p-4 space-y-1">
            <div className="flex items-center justify-between">
              <h2 className="card-title text-sm">📈 EQUITY PATH</h2>
              {isEquityRecommended && <span className="badge badge-success badge-sm">RECOMMENDED</span>}
            </div>

            <SectionHeader title="VALUATION" subtitle="INPUTS" />
            <InputRow label="Pre-Money Valuation" value={inputs.equityPreMoneyVal} onChange={(v) => update('equityPreMoneyVal', v)} type="currency" highlight />
            <InputRow label="Revenue Multiple (Exit)" value={inputs.revenueMultiple} onChange={(v) => update('revenueMultiple', v)} highlight />

            <SectionHeader title="EXIT PROJECTION" subtitle="INPUTS" />
            <InputRow label="Years to Exit" value={inputs.projectedExitYear} onChange={(v) => update('projectedExitYear', v)} highlight />
            <InputRow label="Projected Exit Revenue" value={inputs.projectedExitRevenue} onChange={(v) => update('projectedExitRevenue', v)} type="currency" highlight />

            <SectionHeader title="DILUTION ANALYSIS" subtitle="OUTPUTS" />
            <OutputRow label="Post-Money Valuation" value={fmtCurrency(out.postMoneyVal)} />
            <OutputRow label="Investor Ownership %" value={fmtPct(out.equityDilution)} danger />
            <OutputRow label="Founder Retained %" value={fmtPct(out.impliedOwnershipRetained)} accent />
            <OutputRow label="Investor Return at Exit" value={fmtCurrency(out.investorReturnAtExit)} />
            <OutputRow label="Founder Value at Exit" value={fmtCurrency(out.founderValueAtExit)} accent bold />
            <OutputRow label="Implied Cost of Equity" value={fmtCurrency(out.costOfEquity)} bold />
            <OutputRow label="Cost as Multiple of Capital" value={fmtNumber(out.equityCostAsMultiple, 2) + 'x'} />
          </div>
        </div>
      </div>

      {/* VERDICT */}
      <div className={`p-6 rounded-xl text-center ${
        out.recommendation.startsWith('DEBT') ? 'bg-success/10 border-2 border-success' :
        out.recommendation.startsWith('EQUITY') ? 'bg-info/10 border-2 border-info' :
        out.recommendation.startsWith('NEITHER') ? 'bg-error/10 border-2 border-error' :
        'bg-warning/10 border-2 border-warning'
      }`}>
        <h3 className="text-lg font-bold mb-2">⚖️ THE VERDICT</h3>
        <p className="text-base font-semibold">{out.recommendation}</p>
        <div className="flex justify-center gap-8 mt-4 text-sm">
          <div>
            <span className="text-base-content/60">Total Cost of Debt:</span>
            <span className="font-mono font-bold ml-2">{fmtCurrency(out.debtTotalCost)}</span>
          </div>
          <div>
            <span className="text-base-content/60">Implied Cost of Equity:</span>
            <span className="font-mono font-bold ml-2">{fmtCurrency(out.equityTotalCost)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
