import React, { useState, useMemo } from 'react';

import { TabId, ChannelInputs, CogsFreightState, GlobalOverhead, BreakevenInputs, DebtEquityInputs } from './types';
import { defaultCogsFreight, defaultChannels, defaultDashboardMix, defaultGlobalOverhead, defaultBreakevenInputs, defaultDebtEquityInputs } from './utils/defaults';
import { computeBlendedFinancials } from './utils/calculations';
import { CogsBuilder } from './components/CogsBuilder';
import { ChannelTab } from './components/ChannelTab';
import { CompanyOverhead } from './components/CompanyOverhead';
import { BreakevenTab } from './components/BreakevenTab';
import { DebtEquityTab } from './components/DebtEquityTab';
import { Dashboard } from './components/Dashboard';
import { BarChart3, Truck, Store, ShoppingCart, Globe, Utensils, LayoutDashboard, Building2, Target, Scale } from 'lucide-react';

interface TabDef {
  id: TabId;
  label: string;
  shortLabel: string;
  icon: React.ReactNode;
  group?: 'build' | 'channels' | 'company';
}

const tabs: TabDef[] = [
  { id: 'cogs', label: 'COGS & FREIGHT BUILDER', shortLabel: 'COGS', icon: <Truck size={16} />, group: 'build' },
  { id: 'kehe', label: "NAT'L DISTRIBUTION", shortLabel: "Nat'l Dist", icon: <Store size={16} />, group: 'channels' },
  { id: 'club', label: 'CLUB', shortLabel: 'Club', icon: <ShoppingCart size={16} />, group: 'channels' },
  { id: 'dsd', label: 'DSD', shortLabel: 'DSD', icon: <Truck size={16} />, group: 'channels' },
  { id: 'online', label: 'ONLINE D2B', shortLabel: 'Online', icon: <Globe size={16} />, group: 'channels' },
  { id: 'altfdsvc', label: 'ALT FDSVC', shortLabel: 'Alt FdSvc', icon: <Utensils size={16} />, group: 'channels' },
  { id: 'overhead', label: 'COMPANY OVERHEAD', shortLabel: 'Overhead', icon: <Building2 size={16} />, group: 'company' },
  { id: 'breakeven', label: 'BREAKEVEN & EBITDA', shortLabel: 'Breakeven', icon: <Target size={16} />, group: 'company' },
  { id: 'debtequity', label: 'DEBT vs EQUITY', shortLabel: 'Debt/Equity', icon: <Scale size={16} />, group: 'company' },
  { id: 'dashboard', label: 'EXECUTIVE DASHBOARD', shortLabel: 'Dashboard', icon: <LayoutDashboard size={16} />, group: 'company' },
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabId>('cogs');
  const [cogsFreight, setCogsFreight] = useState<CogsFreightState>(defaultCogsFreight);
  const [channels, setChannels] = useState<Record<string, ChannelInputs>>(defaultChannels);
  const [globalOverhead, setGlobalOverhead] = useState<GlobalOverhead>(defaultGlobalOverhead);
  const [dashboardMix, setDashboardMix] = useState<Record<string, number>>(defaultDashboardMix);
  const [targetRev, setTargetRev] = useState<number>(1000000);
  const [breakevenInputs, setBreakevenInputs] = useState<BreakevenInputs>(defaultBreakevenInputs);
  const [debtEquityInputs, setDebtEquityInputs] = useState<DebtEquityInputs>(defaultDebtEquityInputs);

  const updateChannel = (id: string, ch: ChannelInputs) => {
    setChannels((prev) => ({ ...prev, [id]: ch }));
  };

  const updateMix = (id: string, val: number) => {
    setDashboardMix((prev) => ({ ...prev, [id]: val }));
  };

  // Compute blended financials once — shared by Dashboard, Breakeven, Debt/Equity
  const blended = useMemo(
    () => computeBlendedFinancials(channels, cogsFreight, globalOverhead, dashboardMix, targetRev),
    [channels, cogsFreight, globalOverhead, dashboardMix, targetRev]
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'cogs':
        return <CogsBuilder state={cogsFreight} onChange={setCogsFreight} />;
      case 'kehe':
      case 'club':
      case 'dsd':
      case 'online':
      case 'altfdsvc':
        return (
          <ChannelTab
            channel={channels[activeTab]}
            cogsState={cogsFreight}
            onChange={(ch) => updateChannel(activeTab, ch)}
          />
        );
      case 'overhead':
        return <CompanyOverhead overhead={globalOverhead} onChange={setGlobalOverhead} />;
      case 'breakeven':
        return <BreakevenTab blended={blended} inputs={breakevenInputs} onChange={setBreakevenInputs} />;
      case 'debtequity':
        return <DebtEquityTab blended={blended} inputs={debtEquityInputs} onChange={setDebtEquityInputs} />;
      case 'dashboard':
        return (
          <Dashboard
            blended={blended}
            dashboardMix={dashboardMix}
            targetRev={targetRev}
            onMixChange={updateMix}
            onTargetRevChange={setTargetRev}
          />
        );
      default:
        return null;
    }
  };

  // Group separator rendering
  const groupColors: Record<string, string> = {
    build: 'text-base-content/30',
    channels: 'text-base-content/30',
    company: 'text-base-content/30',
  };

  let lastGroup = '';

  return (
    <div className="flex flex-col h-screen bg-base-100">
      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 py-3 bg-base-200 border-b border-base-300">
        <img src="/logo.png" alt="RLB Logo" className="h-8 w-auto" />
        <div>
          <h1 className="text-sm font-bold text-primary tracking-wider">TRUE MARGIN CPG</h1>
        </div>
      </div>

      {/* Tab navigation */}
      <div className="flex overflow-x-auto bg-base-200 border-b border-base-300 px-2 gap-0.5 scrollbar-thin items-end">
        {tabs.map((tab) => {
          const showSep = tab.group && tab.group !== lastGroup && lastGroup !== '';
          lastGroup = tab.group || '';
          return (
            <React.Fragment key={tab.id}>
              {showSep && <div className="w-px h-6 bg-base-content/10 mx-1 mb-2"></div>}
              <button
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium whitespace-nowrap rounded-t-lg transition-colors ${
                  activeTab === tab.id
                    ? 'bg-base-100 text-primary border-t-2 border-primary'
                    : 'text-base-content/60 hover:text-base-content hover:bg-base-300/50'
                }`}
              >
                {tab.icon}
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.shortLabel}</span>
              </button>
            </React.Fragment>
          );
        })}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {renderContent()}
      </div>

      {/* Footer */}
      <div className="px-4 py-1.5 bg-base-200 border-t border-base-300 text-center">
        <span className="text-xs text-base-content/40">© 2026 Right Lane Brands, Inc. All Rights Reserved.</span>
      </div>
    </div>
  );
};

export default App;
