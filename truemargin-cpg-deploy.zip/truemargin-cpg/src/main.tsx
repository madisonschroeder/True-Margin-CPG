import './index.css'
import React, { useState } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Landing from './Landing'
import App from './App'

function PasswordGate({ children }: { children: React.ReactNode }) {
  const [authenticated, setAuthenticated] = useState(
    () => sessionStorage.getItem('tm_auth') === 'true'
  )
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  // Simple password gate - you set this password and share with paying customers
  const VALID_PASSWORD = 'TRUEMARGIN2026'

  if (authenticated) return <>{children}</>

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-2xl p-8 max-w-md w-full shadow-2xl border border-gray-700">
        <div className="text-center mb-6">
          <img src="/logo.png" alt="Right Lane Brands" className="h-12 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white">True Margin CPG</h2>
          <p className="text-gray-400 mt-2">Enter your access code to continue</p>
        </div>
        <form onSubmit={(e) => {
          e.preventDefault()
          if (password === VALID_PASSWORD) {
            sessionStorage.setItem('tm_auth', 'true')
            setAuthenticated(true)
          } else {
            setError('Invalid access code')
          }
        }}>
          <input
            type="password"
            value={password}
            onChange={e => { setPassword(e.target.value); setError('') }}
            placeholder="Access Code"
            className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 mb-3"
          />
          {error && <p className="text-red-400 text-sm mb-3">{error}</p>}
          <button
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
          >
            Access Dashboard
          </button>
        </form>
        <p className="text-gray-500 text-xs text-center mt-4">
          Don't have an access code? <a href="/" className="text-blue-400 hover:underline">Subscribe here</a>
        </p>
      </div>
    </div>
  )
}

function Root() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/app" element={
          <PasswordGate>
            <App />
          </PasswordGate>
        } />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')!).render(<Root />)
