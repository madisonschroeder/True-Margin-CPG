# True Margin CPG

## Quick Deploy to Vercel (5 minutes)

### Option A: Deploy via Vercel CLI
1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel` in this directory
3. Follow prompts — it auto-detects Vite

### Option B: Deploy via GitHub
1. Push this repo to GitHub
2. Go to vercel.com → New Project → Import from GitHub
3. It auto-detects Vite and deploys

### Option C: One-click deploy
1. Go to vercel.com
2. Click "Add New" → "Project"
3. Drag and drop this folder
4. Done!

## After Deploying

### Connect to mirepoixpartners.com
1. In Vercel dashboard → your project → Settings → Domains
2. Add `app.mirepoixpartners.com`
3. Vercel gives you a CNAME record
4. In Squarespace → Domains → DNS Settings → add a CNAME:
   - Host: `app`
   - Value: `cname.vercel-dns.com`
5. Wait a few minutes for DNS to propagate

### Customer Access Flow
1. Customer pays at Stripe link
2. You send them access code: `TRUEMARGIN2026`
3. They go to app.mirepoixpartners.com/app
4. Enter access code → full access

### Change the Access Code
Edit `src/main.tsx` line with `VALID_PASSWORD` and redeploy.

## Stripe Payment Link
https://buy.stripe.com/test_3cI9AT9sG5Dd3oX0yv3cc00
